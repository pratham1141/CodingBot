# E-Commerce Platform Testing

Automated tests using Selenium and Pytest.
