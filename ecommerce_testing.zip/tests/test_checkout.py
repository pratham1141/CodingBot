# Add checkout test here
